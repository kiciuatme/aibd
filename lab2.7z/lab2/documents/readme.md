Lab. 2 Analiza i Bazy Danych AiR/EAIiIB s7 2021/2022

It is just a data conversion demo, keep scrolling

Reason: "billboard.csv - notowania billboardu (w tabeli jest data wejścia na listę i ranking w kolejnych tygodniach, nie da się wprost odczytać rankingu w danym tygodniu kalendarzowym i jest dużo pustych miejsc)"